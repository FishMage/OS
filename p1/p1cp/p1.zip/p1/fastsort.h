//
//  fastsort.h
//  
//
//  Created by Richard Chen on 1/28/16.
//
//

#ifndef fastsort_h
#define fastsort_h

#include <stdio.h>

#endif /* fastsort_h */
int readlines(char *lineptr[],FILE *fp);

void outputResult(char *lineptr[], int sorted[], int nlines);

int getWords(char *lineptr[], char*wordptr[], int index, int nlines);

