#include "fastsort.h"
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdlib.h>
#include <string.h>

#define MAXLINE 500

int wordIndex;
FILE *fp;
int nlines;

char * dataLineptr[MAXLINE];
char * outputLineptr[MAXLINE];
char * wordpointer[MAXLINE];
char * compareWordptr[MAXLINE];


int readlines(char *lineptr[],FILE *fp);

void outputResult(char *lineptr[], int sorted[], int nlines);

int getWords(char *lineptr[], char*wordptr[], int index, int nlines);

int readlines(char *lineptr[],FILE *fp){
    int lineCount = 0;
    int i = 0;
    while (fgets(lineptr[i], MAXLINE, fp) != NULL)  {
        lineptr[i] = (char*)malloc(sizeof(char)*MAXLINE);
        if (lineptr[i]  == NULL){
            fprintf(stderr, "Error: Failed to allocate memory.\n");
            exit(1);
        }
        if (lineptr[i] == NULL) {
            return -1;
        }
        i++;
        lineCount++;
    }
    return lineCount;
}

void outputResult(char *lineptr[], int sorted[], int nlines){
    int index;
    for (int j = 0; j < nlines; j++) {
        index = sorted[j];
        printf("%s\n",lineptr[index]);
    }
}

int getWords(char *lineptr[], char*wordptr[], int index, int nlines){
    char* temp;
    
    for (int i = 0; i < nlines; i++) {
        for (int j = 0; j <= index; j++) {
            temp = strtok(lineptr[j]," ");
            if (temp == NULL) {
                return -1;
            }
        }
        wordptr[i] = temp;
    }
    return 0;
}

//compare function for qsort
int compare(const void *k1, const void * k2){
    int i1 =  atoi(k1);
    int i2 =  atoi(k2);
    return i1 - i2;
}

int main(int argc, char*argv[]){
    if (argc > 2) {
        fprintf(stderr," Error: Bad command line parameters\n");
        exit(1);
    }
    int fileindex = 0;
    if (argc <= 2) {
        if (argc == 1 ) {
            wordIndex =1;
            fileindex = 0;
        }else{
            //1st Argument: calculate the index of the word in the sentence given
            int charWord = atoi(argv[0]);
            wordIndex = -charWord -1;
            fileindex = 1;
        }
            //2nd argument: open the file and store the data
            fp = fopen(argv[fileindex],"r");
            if (fp == NULL ){
                fprintf(stderr,"Error: Cannot open file %s\n", argv[1]);
                exit(1);
            }
            
            struct stat fileStat;
            int fd = fileno(fp);
            if (fstat(fd, &fileStat) < 0)
            return 1;
            //int fsize = (int)fileStat.st_size;
            
            nlines = readlines(dataLineptr, fp);
            readlines(outputLineptr, fp);
            
            if(getWords(dataLineptr, wordpointer, wordIndex, nlines)< 0){
                fprintf(stderr,"Error\n");
                exit(1);
            }
            
            if(getWords(dataLineptr, compareWordptr, wordIndex, nlines) < 0){
                fprintf(stderr,"Error\n");
                exit(1);
            }
            
            
            //qsort(void *base, size_t nel, size_t width,
            //int (*compar)(const void *, const void *));
            qsort(&dataLineptr[0], nlines, sizeof(char*)*50, compare);
            
            //find the sortedOrder
            int sortedOrder[nlines];
            
            for(int i = 0; i < nlines; i++){
                for(int j = 0; j < 50; j++){
                    if(strcmp(wordpointer[i],compareWordptr[j])== 0)
                    sortedOrder[i] = j;
                }
            }
            //print the result
            outputResult(outputLineptr, sortedOrder, nlines);
            free(dataLineptr);
            free(outputLineptr);
            fclose(fp);
        }
    
    return 0;
}

