#include "types.h"
#include "user.h"
#include "stat.h"
#include "fs.h"

void func(void*);
